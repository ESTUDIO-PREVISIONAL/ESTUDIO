/**
 * CÓDIGO PARA GOOGLE APPS SCRIPT (versión ampliada)
 * Reemplaza al código anterior. Hace DOS cosas:
 * 1) Sigue recibiendo las consultas del formulario público de la web (sin cambios para vos).
 * 2) Además, alimenta el Panel Interno (panel-interno.html): guarda y lee Casos, Pagos y Gastos.
 *
 * INSTALACIÓN (reemplaza el código anterior):
 * 1) Abrí tu Google Sheet → Extensiones → Apps Script
 * 2) Borrá todo el código viejo y pegá este completo
 * 3) Implementar → Gestionar implementaciones → ícono de lápiz → Versión: "Nueva versión" → Implementar
 *    (la URL /exec NO cambia, así que no hay que tocar nada en la web pública)
 * 4) Las pestañas Consultas, Casos, Pagos y Gastos se crean solas la primera vez que se usan.
 */

function getSheet(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (name === "Casos") {
      sheet.appendRow(["ID Caso", "Cliente", "Especialidad", "Fecha inicio", "Estado", "Último avance", "Honorarios pactados"]);
    } else if (name === "Pagos") {
      sheet.appendRow(["Fecha", "ID Caso", "Cliente", "Monto", "Método", "Observaciones"]);
    } else if (name === "Gastos") {
      sheet.appendRow(["Fecha", "ID Caso", "Concepto", "Monto", "Comprobante"]);
    }
  }
  return sheet;
}

function sheetToObjects(sheet) {
  var data = sheet.getDataRange().getValues();
  if (data.length < 2) return [];
  var headers = data[0];
  var rows = data.slice(1);
  return rows
    .filter(function(row){ return row.join("") !== ""; })
    .map(function(row){
      var obj = {};
      headers.forEach(function(h, i){ obj[h] = row[i]; });
      return obj;
    });
}

// ---- GET: el panel interno pide todos los datos ----
function doGet(e) {
  var casos = sheetToObjects(getSheet("Casos"));
  var pagos = sheetToObjects(getSheet("Pagos"));
  var gastos = sheetToObjects(getSheet("Gastos"));

  return ContentService.createTextOutput(
    JSON.stringify({ casos: casos, pagos: pagos, gastos: gastos })
  ).setMimeType(ContentService.MimeType.JSON);
}

// ---- POST: puede ser una consulta pública (web) o una acción del panel interno ----
function doPost(e) {
  var action = e.parameter.action || "consulta";

  if (action === "consulta") {
    return handleConsultaPublica(e);
  } else if (action === "nuevoCaso") {
    var casos = getSheet("Casos");
    casos.appendRow([
      e.parameter.id, e.parameter.cliente, e.parameter.especialidad,
      e.parameter.fechaInicio, e.parameter.estado || "En curso",
      e.parameter.ultimoAvance || "", e.parameter.honorarios || 0
    ]);
  } else if (action === "actualizarCaso") {
    var casosSheet = getSheet("Casos");
    var data = casosSheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(e.parameter.id)) {
        casosSheet.getRange(i + 1, 5).setValue(e.parameter.estado || data[i][4]);
        casosSheet.getRange(i + 1, 6).setValue(e.parameter.ultimoAvance || data[i][5]);
        if (e.parameter.honorarios) casosSheet.getRange(i + 1, 7).setValue(e.parameter.honorarios);
        break;
      }
    }
  } else if (action === "nuevoPago") {
    var pagos = getSheet("Pagos");
    pagos.appendRow([
      e.parameter.fecha, e.parameter.id, e.parameter.cliente,
      e.parameter.monto, e.parameter.metodo || "", e.parameter.observaciones || ""
    ]);
  } else if (action === "nuevoGasto") {
    var gastos = getSheet("Gastos");
    gastos.appendRow([
      e.parameter.fecha, e.parameter.id, e.parameter.concepto,
      e.parameter.monto, e.parameter.comprobante || ""
    ]);
  }

  return ContentService.createTextOutput(
    JSON.stringify({ result: "ok" })
  ).setMimeType(ContentService.MimeType.JSON);
}

// ---- Lógica original: consulta pública desde la web (sin cambios de comportamiento) ----
function handleConsultaPublica(e) {
  var sheet = getSheet("Consultas");
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["Fecha", "Nombre", "Contacto", "Tema", "Mensaje"]);
  }

  var nombre = e.parameter.nombre || "";
  var contacto = e.parameter.contacto || "";
  var tema = e.parameter.tema || "";
  var mensaje = e.parameter.mensaje || "";
  var fecha = new Date();

  sheet.appendRow([fecha, nombre, contacto, tema, mensaje]);

  var destinatario = "gonzalezyasociadoslegales@gmail.com";
  var asunto = "Nueva consulta web: " + nombre + " (" + tema + ")";
  var cuerpo = "Nombre: " + nombre + "\n" +
               "Contacto: " + contacto + "\n" +
               "Tema: " + tema + "\n" +
               "Mensaje: " + mensaje + "\n\n" +
               "Se guardó automáticamente en tu planilla de consultas.";

  MailApp.sendEmail(destinatario, asunto, cuerpo);

  return ContentService.createTextOutput(
    JSON.stringify({ result: "ok" })
  ).setMimeType(ContentService.MimeType.JSON);
}
